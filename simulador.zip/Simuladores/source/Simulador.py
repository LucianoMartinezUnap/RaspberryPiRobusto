from SIMNFC import SimulatedNfcReader as SNfc
#from CAM import CamInterface as Cam
from Connect2DB import Connection2DB as C2B
from usermanager import UserManagement as UserMgt
import time
import random
Path = 'dataset'
Reader = SNfc()
AdminCard = open('./AdminUid.txt', 'r').readline()
def main():
    while True:
        try:
            option = int (input("Ingrese tarjeta:\n1. AdminCard\n2. Cualquier Tarjeta\n"))
            if option == 1:
                Reader.ReadCard(int(' '.join(AdminCard.split())))
            elif option == 2:
                Reader.ReadCard(random.randint(100000000000, 999999999999))
            else:
                continue
            C2B.Post2DB('190.114.253.43', 80, '/MVC/Controller/PHP/endpoint.php', Key='nfc', Value = Reader.GetUid())
            print("NFC Checked")
            time.sleep(1)
            Response = C2B.GetProviderConfirmation(Reader.GetUid(), '190.114.253.43', '/MVC/Controller/PHP/endpoint.php')
            Response = Response.read().decode()
            Response = ' '.join(Response.split())
            print(len(Response))
            if Response in 'Logear':
                UserMgt.LoginUser(Reader)
                continue
            elif Response in 'Crear':
                UserMgt.RegisterUser(Reader)
                continue
            else:
                print('Respuesta negativa recibida')
            time.sleep(1)

        except Exception as e:
            print(f"Error :{e} ha ocurrido")

if __name__ == "__main__":
    main()
