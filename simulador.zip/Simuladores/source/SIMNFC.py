class SimulatedNfcReader:
    __Uid = None

    def __init__(self):
        pass
    def ReadCard(self, Id):
        self.__Uid = Id
    def GetUid(self):
        return self.__Uid
